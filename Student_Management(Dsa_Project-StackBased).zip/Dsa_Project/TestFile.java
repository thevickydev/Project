import java.util.Scanner;
public class TestFile {
private ArrayStack<Student> record;
private Scanner input;
private int counter;
public TestFile() {
	record = new ArrayStack<>();
	input = new Scanner(System.in);
	 counter = 0;
}
public void add() {
	String name = null, department = null;
	int roll = 0;
	double gpa = 0;
	try {
	System.out.print("Enter Student's Name: ");
	 name = input.nextLine();
	System.out.print("Enter Student's Department: ");
	 department = input.nextLine();
	System.out.print("Enter Student's ID: ");
	 roll = Integer.parseInt(input.nextLine());
	System.out.print("Enter Student's CGPA: ");
	 gpa = Double.parseDouble(input.nextLine());
	record.Push(new Student(name,department,roll,gpa));
	} catch(Exception e) {
		System.out.println("You've entered wrong information...");
	}
	counter++;
	System.out.println("Name: "+name+" \tDepartment: "+department+"\tRoll Number: "+roll+"\tCgpa: "+gpa);
	System.out.println("Student is added successfully!");
}

public void remove() {
		if(!record.isEmpty()) {
		System.out.println(record.pop().toString());
	System.out.println("\nLast Student is removed successfully!");
	counter--;
	}//if
		else {
			System.out.println("Not Found!");
		}
	
}
public void look() {
	try {
		if(!record.isEmpty()) {
	System.out.println("\nLatest Student you added: ");
	System.out.println(record.peak().toString());
		} 
	}catch(Exception e) {
			System.out.println("Not Found!");
		}	
}
public void first() {
	ArrayStack<Student> temp = new ArrayStack<>();
	try {  
		while(!record.isEmpty()) {
		   temp.Push(record.pop());
		   
	   }
	   System.out.println(temp.peak().toString());
	   } catch(Exception e) {
		   System.out.println("Not Found!");
	   }
	while(!temp.isEmpty()) {
		   record.Push(temp.pop());
		   
	   }
}
public void addedStudents() {
	System.out.println("You've added Students: "+counter);
}
public void clear() {
	if(counter > 0) {
	record.clear();
	counter = 0;
	System.out.println("\nRecord has Cleared successfully!");
	} else {
		System.out.println("Already Cleared");
	}
}
public void getDisplay() {
	ArrayStack<Student> temp = new ArrayStack<>();
   while(!record.isEmpty()) {
	   if(!record.isEmpty()) {
		   temp.Push(record.pop());
	   }//if
   }//while
   
   while(!temp.isEmpty()) {
	   Student tmp = new Student(temp.pop());
	   System.out.println(tmp.toString());
		record.Push(tmp);
   }//while

}
public boolean search() {
	ArrayStack<Student> temp = new ArrayStack<>();
	System.out.println("Enter Student's details to Search...");
	System.out.print("Enter Student's ID: ");
	int roll = input.nextInt();
	boolean result = false;
	try {
	while(!record.isEmpty()) {
		Student tmp = new Student(record.pop());
		if(roll==tmp.getRollNumber()) {
			System.out.println(tmp.toString());
			result = true;
	}//if
	temp.Push(tmp);
	}//while
	//for maintaining record
	while(!temp.isEmpty()) {
		record.Push(temp.pop());
	}//while

	} catch(Exception e) {
	System.out.println("Not Found!");
	}//exception
	return result;
}//method
}//class
