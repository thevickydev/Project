import java.util.Arrays;

public class AList<T> implements ListInterface<T>
{
	private T[] list;
	private int numberOfEntries;
	private final int DEFAULT_CAPACITY = 25;


	@SuppressWarnings("unchecked")
	public AList(int capacity)
	{
		if (capacity < DEFAULT_CAPACITY)
		{
			capacity = DEFAULT_CAPACITY;
		}

		list = (T[]) new Object[capacity + 1];
		numberOfEntries = 0;
	}

	public AList()
	{
		this(25);
	}

	@Override
	public void add(T entry)
	{
		list[numberOfEntries + 1] = entry;
		numberOfEntries++;

		ensureCapacity();

	}

	@Override
	public void add(int pos, T entry)
	{
		if (pos >= 1 && pos <= numberOfEntries + 1)
		{

			if (pos <= numberOfEntries)
			{
				makeRoom(pos);
			}
			list[pos] = entry;
			System.out.println(entry.toString());
			System.out.println("Successfully added Student at "+pos+" Position");
			numberOfEntries++;
			ensureCapacity();

		} else
		{
			throw new IndexOutOfBoundsException("index out bound value must be 1 to " + numberOfEntries);

		}

	}

	@Override
	public T replace(int pos, T entry)
	{
		if (pos >= 1 && pos <= numberOfEntries)
		{
			T original = list[pos];
			list[pos] = entry;

			return original;
		} 
		else
		{
			throw new IndexOutOfBoundsException("index out bound value must be 1 to " + numberOfEntries);
		}
	}

	@Override
	public void clear()
	{
		numberOfEntries = 0;

	}

	@Override
	public T remove(int pos)
	{
		if (pos >= 0 && pos <= numberOfEntries)
		{
			T toReturn = list[pos];
			if (pos < numberOfEntries)
			{
				removeGap(pos);
			}
			numberOfEntries--;
			return toReturn;

		} else
		{
			throw new IndexOutOfBoundsException("index out bound value must be 1 to " + numberOfEntries);
		}
	}

	@Override
	public T getEntry(int pos)
	{
		if (pos >= 1 && pos <= numberOfEntries)
		{
			return list[pos];
		} else
		{
			throw new IndexOutOfBoundsException("index out bound value must be 1 to " + numberOfEntries);
		}
	}

	@Override
	public T[] toArray()
	{

		@SuppressWarnings("unchecked")
		T[] temp = (T[]) new Object[numberOfEntries];

		for (int i = 0; i < numberOfEntries; i++)
		{
			temp[i] = list[i + 1];
		}
		return temp;

	}

	@Override
	public int getLength()
	{

		return numberOfEntries;
	}

	@Override
	public boolean isEmpty()
	{

		return numberOfEntries == 0;
	}

	@Override
	public boolean contains(T entry)
	{
		for (int i = 1; i <= numberOfEntries; i++)
		{
			if(list[i].equals(entry))
			{
				System.out.println(list[i].toString());
				remove(i);
				return true;
			}
		}
		return false;
	}

	private void ensureCapacity()
	{
		int capacity = list.length - 1;

		if (numberOfEntries == capacity)
		{
			int newCapacity = capacity * 2;

			T[] temp = Arrays.copyOf(list, newCapacity);

			list = temp;

		}

	}

	private void makeRoom(int pos)
	{
		int lastIndex = numberOfEntries;
		for (int index = lastIndex; index >= pos; index--)
		{
			list[index + 1] = list[index];
		}
	}

	private void removeGap(int pos)
	{
		for (int index = pos; index < numberOfEntries; index++)
		{
			list[index] = list[index + 1];
		}
	}

    @Override
    public void addBeginning(T newEntry) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateBeginning(T newEntry) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeBeginning(int givenPosition) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
