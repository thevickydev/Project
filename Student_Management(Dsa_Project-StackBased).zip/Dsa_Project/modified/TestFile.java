
import java.util.*;
public class TestFile{
private AList<Student> record;
private Scanner input;

public TestFile() {
	record = new AList<>();
	input = new Scanner(System.in);
}
public void add() {
	
	String name = null, department = null;
	int roll = 0;
	double gpa = 0;
	try {
	System.out.print("Enter Student's Name: ");
	 name = input.nextLine();
	 input.nextLine();
	System.out.print("Enter Student's Department: ");
	 department = input.nextLine();
	System.out.print("Enter Student's ID: ");
	 roll = Integer.parseInt(input.nextLine());
	System.out.print("Enter Student's CGPA: ");
	 gpa = Double.parseDouble(input.nextLine());
	record.add(new Student(name,department,roll,gpa));
	} catch(Exception e) {
		System.out.println("You've entered wrong information...");
	}
	System.out.println("Name: "+name+" \tDepartment: "+department+"\tRoll Number: "+roll+"\tCgpa: "+gpa);
	System.out.println("Student is added successfully!");
}
public void remove() {
	System.out.println("Enter 1 to remove by Roll Number ");
	System.out.println("Enter 2 to remove by Name ");
	System.out.println("Enter 3 to remove Student by Attributes ");
	System.out.println("Enter 0 to go back ");
	int value = input.nextInt();
	while (value != 0) {
		switch (value) {

			case 1:{
			removeByRoll();
			break;
			}
			case 2:{
				removeByName();
			    break;
			}//case
			case 3:{
				removeByAttributes();
			    break;
			}//case
		}//switch
		break;
	}//while
}private void removeByAttributes() {
	// TODO Auto-generated method stub
	String name = null, department = null;
	int roll = 0;
	double gpa = 0;
try {	
	System.out.print("Enter Student's Name: ");
	 name = input.nextLine();
	System.out.print("Enter Student's Department: ");
	 department = input.nextLine();
	System.out.print("Enter Student's ID: ");
	 roll = Integer.parseInt(input.nextLine());
	System.out.print("Enter Student's CGPA: ");
	 gpa = Double.parseDouble(input.nextLine());
	 if(record.contains(new Student(name,department,roll,gpa))) {
		System.out.println("Successfully removed! ");
	 } else {
		 System.out.println("Not Found! ");
	 }
	} catch(Exception e) {
		System.out.println("You've entered wrong information! ");
	}
}//method
public void removeByName() {
try { 
	System.out.print("Enter Name to Remove: ");
	String name = input.next();
	boolean result = false;
	for (int i = 1; i <= record.getLength(); i++) {
		if(record.getEntry(i).getName().toLowerCase().equals(name.toLowerCase())) {
			System.out.println(record.getEntry(i).toString()+"\nFound!\n");
			result = true;
			record.remove(i);
			System.out.println("Successfully removed! ");
			System.out.println("Now you've "+record.getLength()+" Students");
		}
	}if(!result) {
		System.out.println("Not Found! ");
}
} catch(Exception e) {
	System.out.println("You've entered wrong information...");
}//try
}

public void removeByRoll() {
	try {
		System.out.print("Enter Roll Number to Remove: ");
		int roll = input.nextInt();
		boolean result = false;
		for (int i = 1; i <=record.getLength(); i++) {
			if(record.getEntry(i).getRollNumber()==roll) {
				System.out.println(record.getEntry(i).toString()+"\nFound!\n");
				result = true;
				record.remove(i);
				System.out.println("Successfully removed! ");
				System.out.println("Now you've "+record.getLength()+" Students");
			}	
		}if(!result) {
			System.out.println("Not Found! ");
	}
	} catch(Exception e) {
		System.out.println("You've entered wrong information...");
	}
}
public void noOfSt() {	
	System.out.println("You've added Students: "+record.getLength());
}
public void search() {
	System.out.println("Enter 1 to search by Name ");
	System.out.println("Enter 2 to search by Roll Number ");
	System.out.println("Enter 3 to search Student by Attributes ");
	System.out.println("Enter 0 to go back ");
	int value = input.nextInt();
	while (value != 0) {
		switch (value) {

			case 1:{
			searchByName();
			break;
			}
			case 2:{
				searchByRoll();
			    break;
			}//case
			case 3:{
				searchByAttributes();
			    break;
			}//case
		}//switch
		break;
	}//while
	
}
private void searchByAttributes() {
	String name = null, department = null;
	int roll = 0;
	double gpa = 0;
try {	
	System.out.print("Enter Student's Name: ");
	 name = input.nextLine();
	System.out.print("Enter Student's Department: ");
	 department = input.nextLine();
	System.out.print("Enter Student's ID: ");
	 roll = Integer.parseInt(input.nextLine());
	System.out.print("Enter Student's CGPA: ");
	 gpa = Double.parseDouble(input.nextLine());
	 boolean result = false;
		for (int i = 1; i <= record.getLength(); i++) {
			if(record.getEntry(i).equals( new Student(name,department,roll,gpa))) {
				result = true;
				System.out.println(record.getEntry(i).toString()+"\nFound! At "+i+" Position");
			}		
		}if(!result) {
			System.out.println("Not Found! ");
	}
	} catch(Exception e) {
		System.out.println("You've entered wrong information...");
	}
}
private void searchByRoll() {
	try {
		boolean result = false;
		System.out.print("Enter Roll Number to Search: ");
		int roll = input.nextInt();
		for (int i = 1; i <= record.getLength(); i++) {
			if(record.getEntry(i).getRollNumber()==roll) {
				result = true;
				System.out.println(record.getEntry(i).toString()+"\nFound! At "+i+" Position");
			}	
		} if(!result) {
				System.out.println("Not Found! ");
		}
	} catch(Exception e) {
		System.out.println("You've entered wrong information...");
	}
}
public void searchByName() {
	try { 
		System.out.print("Enter Name to Search: ");
		String name = input.next();
		boolean result = false;
		for (int i = 1; i <= record.getLength(); i++) {
			if(record.getEntry(i).getName().toLowerCase().equals(name.toLowerCase())) {
				result = true;
				System.out.println(record.getEntry(i).toString()+"\nFound! At "+i+" Position");
			}
		}if(!result) {
			System.out.println("Not Found! ");
	}
	} catch(Exception e) {
		System.out.println("You've entered wrong information...");
	}//try
}

@SuppressWarnings("unchecked")
public void getList() {
	System.out.println("Enter 1 to get list Sorted by Names ");
	System.out.println("Enter 2 to get list Sorted by Roll Numbers ");
	System.out.println("Enter 3 to get list Sorted by Cgpa ");
	System.out.println("Enter 4 to get list Sorted by Department ");
	System.out.println("Enter 5 to get General List ");
	System.out.println("Enter 0 to go back ");
	int value = input.nextInt();
	@SuppressWarnings("rawtypes")
	ArrayList temp = toList();
	while (value != 0) {
		switch (value) {
			case 1: {
				Collections.sort(temp, new Sortbyname());
				print(temp);
				break;
			}
			case 2:{
				Collections.sort(temp, new Sortbyroll());
				print(temp);
			break;
			}
			case 3:{
				Collections.sort(temp,Comparator.comparingDouble(Student::getCgpa));
				print(temp);
			    break;
			}
			case 4:{
				Collections.sort(temp, new Sortbydepartment());
				print(temp);
				break;
			}
			case 5:{
				print(temp);
				break;
			}//cases
		}//switch
		break;
	}//while
}
public void print(@SuppressWarnings("rawtypes") ArrayList array) {
	for (int i = 0; i < array.size(); i++) {
		System.out.println(array.get(i).toString());
}
}
public void clear() {
	record.clear();
	System.out.println("You've Successfully cleared all the record \nNow,\n");
	noOfSt();
	
}
public void remAtPos() {
	System.out.println("Enter position to remove");
	int temp = input.nextInt();
	if(record.contains(record.getEntry(temp))) {
	record.remove(temp);
	System.out.println("Successfully removed  "+temp+"  Student! ");
	System.out.println("Now you've "+record.getLength()+" Students");
	} else {
		System.out.println("Not Found! ");
	}
}
public void entryPos() {
	String name = null, department = null;
	int roll = 0;
	double gpa = 0;
try {	
	System.out.println("Enter Position to add new Student");
	int pos = input.nextInt();
	System.out.print("Enter Student's Name: ");
	 name = input.nextLine();
	System.out.print("Enter Student's Department: ");
	 department = input.nextLine();
	System.out.print("Enter Student's ID: ");
	 roll = Integer.parseInt(input.nextLine());
	System.out.print("Enter Student's CGPA: ");
	 gpa = Double.parseDouble(input.nextLine());
	 record.add(pos, new Student(name,department,roll,gpa));	
	} catch(Exception e) {
		System.out.println("You've entered wrong information! ");
	}
	
}
@SuppressWarnings({ "unchecked", "rawtypes" })
public ArrayList toList() {
	Object[] temp = record.toArray();
	ArrayList obj = new ArrayList();
	for (int i = 0; i < temp.length; i++) {
		obj.add(temp[i]);
	}
	return obj;
}
//------------------------------------------------(Comparator Classes)--------------------------------------------------------------

//class 1
class Sortbyroll implements Comparator<Student> {

public int compare(Student a, Student b)
{

    return a.getRollNumber() - b.getRollNumber();
}
}

//Class 2
class Sortbyname implements Comparator<Student> {

// Method
// Sorting in ascending order of name
public int compare(Student a, Student b)
{

    return a.getName().toLowerCase().compareTo(b.getName().toLowerCase());
}
}
//class 3
class Sortbycgpa implements Comparator<Student> {
	 
// Method
// Sorting in ascending order of name
public int compare(Student a, Student b)
{

    return (int) (a.getCgpa() - b.getCgpa());
}
}
//class 4
class Sortbydepartment implements Comparator<Student> {
	 
// Method
// Sorting in ascending order of name
public int compare(Student a, Student b)
{

    return a.getDepartment().toLowerCase().compareTo(b.getDepartment().toLowerCase());
}
}



//----------------------------------------------------------(end)--------------------------------------------------------------
}//TestFile

