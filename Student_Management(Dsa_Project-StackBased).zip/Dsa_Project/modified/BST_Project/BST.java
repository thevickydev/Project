public class BST<T> { 
	@SuppressWarnings("hiding")
	class Node<T> { 
		Student key; 
		Node<T> left, right; 

		public Node(Student item) { 
			key = item; 
			left = right = null; 
		} 
	} 

	// Root of BST 
	Node<T> root; 

	// Constructor 
	BST() { 
		root = null; 
	} 

	// This method mainly calls deleteRec() 
	boolean deleteKey(Student key) { 
		boolean result = true;
		root = deleteRec(root, key); 
		if(root==null) {
			result = false;
		}
		return result;
	} 

	/* A recursive function to insert a new key in BST */
	Node<T> deleteRec(Node<T> root, Student key) { 
		/* Base Case: If the tree is empty */
		if (root == null) return root; 

		/* Otherwise, recur down the tree */
		if (key.getRollNumber() < root.key.getRollNumber()) 
			root.left = deleteRec(root.left, key); 
		else if (key.getRollNumber() > root.key.getRollNumber()) 
			root.right = deleteRec(root.right, key); 

		// if key is same as root's key, then This is the node 
		// to be deleted 
		else{ 
			// node with only one child or no child 
			if (root.left == null) 
				return root.right; 
			else if (root.right == null) 
				return root.left; 

			// node with two children Get the inorder successor (smallest 
			// in the right subtree) 
			//root.key.setRollNumber(minValue(root.right)); 
			root.key = minValue(root.right);

			// Delete the inorder successor 
			root.right = deleteRec(root.right, root.key); 
		} 

		return root; 
	} 

	Student minValue(Node<T> root) { 
		Student minv = root.key; 
		while (root.left != null) 
		{ 
			minv = root.left.key; 
			root = root.left; 
		} 
		return minv; 
	} 
	
	Student maxValue(Node<T> root) { 
		Student maxv = root.key; 
		while (root.right != null) 
		{ 
			maxv = root.right.key; 
			root = root.right; 
		} 
		return maxv; 
	} 

	// This method mainly calls insertRec() 
	void insert(Student key) { 
		root = insertRec(root, key); 
	} 

	/* A recursive function to insert a new key in BST */
	Node<T> insertRec(Node<T> root, Student key) { 

		/* If the tree is empty, return a new node */
		if (root == null) { 
			root = new Node<T>(key); 
			return root; 
		} 

		/* Otherwise, recur down the tree */
		if (key.getRollNumber() < root.key.getRollNumber()) 
			root.left = insertRec(root.left, key); 
		else if (key.getRollNumber() > root.key.getRollNumber()) 
			root.right = insertRec(root.right, key); 

		/* return the (unchanged) node pointer */
		return root; 
	} 
	//--------------------------------------------------------------------------------
	void inorder() { 
		inorderRec(root); 
	} 

	// A utility function to do inorder traversal of BST 
	void inorderRec(Node<T> root) { 
		if(root!=null){
			inorderRec(root.left);
			System.out.println(root.key.toString());                                                                                                                     
			inorderRec(root.right);
		}
	} 
	//--------------------------------------------------------------------------------
	void preOrder() { 
		preOrderRec(root); 
	} 
	// A utility function to do inorder traversal of BST 
	void preOrderRec(Node<T> root) { 
		if(root!=null){
			System.out.println(root.key.toString());    
			preOrderRec(root.left);                                                                                                         
			preOrderRec(root.right);
		}
	} 
	//--------------------------------------------------------------------------------
	void postOrder() { 
		postOrderRec(root); 
	} 

	// A utility function to do inorder traversal of BST 
	void postOrderRec(Node<T> root) { 
		if(root!=null){    
			postOrderRec(root.left);                                                                                                         
			postOrderRec(root.right);
			System.out.println(root.key.toString());
		}
	} 
	void delName(String str) { 
		delRec(root, str); 
		System.out.println("Not Found");
	} 

	// A utility function to search name
	void delRec(Node<T> root, String str) { 
		if(root!=null){
			if(root.key.getName().toLowerCase().equals(str.toLowerCase())) {
				System.out.println("Found!\n"+root.key.toString()+"\nSuccessfully deleted");  
				if(deleteKey(root.key)) {
					System.out.println("Successfully deleted!");
				}
			}
			doRec(root.left, str);                                                                                                                   
			doRec(root.right, str);
		}
	} 
	//--------------------------------------------------------------------------------
	void printSearch(int value) {
	Node<T> temp =	findNodeInBST(root, value);
	if(temp!=null) {
		System.out.println(temp.key.toString());
	} else {
		System.out.println("Not Found");
	}
	}
	public Node<T> findNodeInBST(Node<T> node, int value) {
        if(null == node) {
            return null;
        }
        //Condition 1. we found the value
        if(node.key.getRollNumber() == value) {
            return node;
        } 
        //Condition 2. 
        //Value is less than node value. so go left sub tree
        else if(value < node.key.getRollNumber())
            return findNodeInBST(node.left,value);
        //Condition 3. 
        //Value is greater than node value. so go right sub tree
        else
            return findNodeInBST(node.right,value);
    }
	//------------------------------------------------------------------------------------------------------------
	void doName(String str) { 
		doRec(root, str); 
		System.out.println("Not Found");
	} 

	// A utility function to search name
	void doRec(Node<T> root, String str) { 
		if(root!=null){
			if(root.key.getName().toLowerCase().equals(str.toLowerCase())) {
				System.out.println("Found!\n"+root.key.toString());  
			}
			doRec(root.left, str);                                                                                                                   
			doRec(root.right, str);
		}
	} 
	void doAttribut(Student i) { 
		rollRec(root, i); 
		System.out.println("Not Found");
	} 

	// A utility function to search student
	void rollRec(Node<T> root, Student i) { 
		if(root!=null){
			if(root.key.equals(i)) {
				System.out.println("Found!\n"+root.key.toString());  
			}
			rollRec(root.left, i);                                                                                                                   
			rollRec(root.right, i);
		}
	} 


}