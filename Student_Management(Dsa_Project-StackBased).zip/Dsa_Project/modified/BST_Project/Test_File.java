import java.util.*;
public class Test_File{
private BST<Student> record;
ArrayList<Student> k;
private Scanner input;
private Scanner in;

public Test_File() {
	record = new BST<>();
	input = new Scanner(System.in);
	in = new Scanner(System.in);
}
public void add() {
	k = new ArrayList<>();
	String name = null, department = null;
	int roll = 0;
	double gpa = 0;
	try {
	System.out.print("Enter Student's Name: ");
	 name = input.next();
	 System.out.print("Enter Student's ID: ");
	 roll = in.nextInt();
	System.out.print("Enter Student's Department: ");
	 department = input.next();	
	System.out.print("Enter Student's CGPA: ");
	 gpa = in.nextDouble();
	 record.insert(new Student(name,department,roll,gpa));
	} catch(Exception e) {
		System.out.println("You've entered wrong information...");
	}
	System.out.println("Name: "+name+" \tDepartment: "+department+"\tRoll Number: "+roll+"\tCgpa: "+gpa);
	System.out.println("Student is added successfully!\n\n");
}

public void remove() {
	System.out.println("Enter 1 to delete by Name ");
	System.out.println("Enter 2 to delete by Roll Number ");
	System.out.println("Enter 3 to delete Student by Attributes ");
	System.out.println("Enter 0 to go back ");
	int value = input.nextInt();
	while (value != 0) {
		switch (value) {

			case 1:{
			deleteByName();
			break;
			}
			case 2:{
				deleteByRoll();
			    break;
			}//case
			case 3:{
				deleteByAttributes();
			    break;
			}//case
		}//switch
		break;
	}//while
}
private void deleteByAttributes() {
	String name = null, department = null;
	int roll = 0;
	double gpa = 0;
try {	
	System.out.print("Enter Student's Name: ");
	 name = input.next();
	 System.out.print("Enter Student's ID: ");
	 roll = in.nextInt();
	System.out.print("Enter Student's Department: ");
	 department = input.next();	
	System.out.print("Enter Student's CGPA: ");
	 gpa = in.nextDouble();
	Student temp =  new Student(name,department,roll,gpa);
	 if(record.deleteKey(temp)) {
		 System.out.println(temp.toString()+"\nSuccessfully deleted");
	 }
	} catch(Exception e) {
		System.out.println("You've entered wrong information...");
	}
	
}
	
private void deleteByRoll() {
	System.out.print("Enter Student's ID: ");
	int  roll = in.nextInt();
	if(record.deleteKey(new Student(null,null,roll,0))){
			 System.out.println("\nSuccessfully deleted");
	} else {
		System.out.println("Not Found");
	}
	
}
private void deleteByName() {
	System.out.print("Enter Student's Name: ");
	 String name = input.next();
	 record.delName(name);
	
}
public void search() {
	System.out.println("Enter 1 to search by Name ");
	System.out.println("Enter 2 to search by Roll Number ");
	System.out.println("Enter 3 to search Student by Attributes ");
	System.out.println("Enter 0 to go back ");
	int value = input.nextInt();
	while (value != 0) {
		switch (value) {

			case 1:{
			searchByName();
			break;
			}
			case 2:{
				searchByRoll();
			    break;
			}//case
			case 3:{
				searchByAttributes();
			    break;
			}//case
		}//switch
		break;
	}//while
}
private void searchByAttributes() {
	String name = null, department = null;
	int roll = 0;
	double gpa = 0;
try {	
	System.out.print("Enter Student's Name: ");
	 name = input.next();
	 System.out.print("Enter Student's ID: ");
	 roll = in.nextInt();
	System.out.print("Enter Student's Department: ");
	 department = input.next();	
	System.out.print("Enter Student's CGPA: ");
	 gpa = in.nextDouble();
	Student temp =  new Student(name,department,roll,gpa);
	 record.doAttribut(temp);
	} catch(Exception e) {
		System.out.println("You've entered wrong information...");
	}
	
}

private void searchByRoll() {
	System.out.print("Enter Student's ID: ");
	int roll = in.nextInt();
	record.printSearch(roll);
}
private void searchByName() {
	System.out.print("Enter Student's Name: ");
	String name = input.next();
	record.doName(name);
	
}
public void print() {
	System.out.println("Enter 1 to print in inorder ");
	System.out.println("Enter 2 to print in preorder ");
	System.out.println("Enter 3 to print in postorder ");
	System.out.println("Enter 0 to go back ");
	int value = input.nextInt();
	while (value != 0) {
		switch (value) {

			case 1:{
			record.inorder();
			break;
			}
			case 2:{
				record.preOrder();
			    break;
			}//case
			case 3:{
				record.postOrder();
			    break;
			}//case
		}//switch
		break;
	}//while
}
}//TestFile

