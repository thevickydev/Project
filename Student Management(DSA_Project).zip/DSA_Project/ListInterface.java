public interface ListInterface<T> {
	public void add(T item);

	public void add(T item, int position);

	public T remove(int position);

	public T replace(int position, T item);

	public int size();

	public boolean contains(T item);

	public T get(int position);

	public boolean isEmpty();

	public void clear();

	public T[] toArray();
}