import java.util.Scanner;

public class RunStudent 
{

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		
		StudentRecord s = new StudentRecord();
		
		
		System.out.println("Press 1 to add student");
		System.out.println("Press 2 to display students");
		System.out.println("Press 3 to update student");
		System.out.println("Press 4 to remove student");
		System.out.println("Press 0 to exit");
		
		System.out.print("\nEnter your choice :");
		int choice = in.nextInt();
		
		while (choice != 0) 
		{
			switch (choice) 
			{
				case 1: 
				{
					s.addStudent();
					break;
				}
				case 2:
				{
					s.displayStudent();
					break;
				}
				case 3:
				{
					s.updateStudent();
					break;
				}
				case 4:
				{
					s.delStudent();
					break;
				}
			
			}
			System.out.println("\nPress 1 to add student");
			System.out.println("Press 2 to display students");
			System.out.println("Press 3 to update student");
			System.out.println("Press 4 to remove student");
			System.out.println("Press 0 to exit");
			
			System.out.print("\nEnter your choice :");
			choice =in.nextInt();
		}
		
	}
	
	

}
