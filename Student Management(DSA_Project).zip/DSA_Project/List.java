public class List<T> implements ListInterface<T> {
    private Node<T> first, last;
    private int count;

    public List() 
    {
    
    }

    public void add(T data) 
    {
        Node<T> n = new Node<>(data);
        if (count == 0)
        {
            first = last = n;
        }
        else 
        {
            last.setNext(n);
            last = n;
        }
        count++;
    }

    public void add(T item, int position) 
    {
        Node<T> newNode = new Node<>(item);
        if (position == 0) 
        {
            newNode.setNext(first);
            first = newNode;
        }
         else 
         {
            Node<T> before = getNodeAt(position - 1);
            Node<T> after = getNodeAt(position);
            before.setNext(newNode);
            newNode.setNext(after);
        }
        count++;
    }

    public T remove(int givenPosition) 
    {
        T toRemove = null;
        if (givenPosition == 0) 
        {
            toRemove = first.getData();
            first = first.getNext();
        } 
        else 
        {
            Node<T> before = getNodeAt(givenPosition - 1);
            toRemove = getNodeAt(givenPosition).getData();

            Node<T> after = getNodeAt(givenPosition + 1);
            before.setNext(after);
        }
        // TODO Auto-generated method stub
        count--;
        return toRemove;
    }

    public void print() 
    {
        Node<T> start = first;
        while (start != null) 
        {
            System.out.print(start.getData() + "\n ");
            start = start.getNext();
        }
        System.out.println();
    }// print method

    public void clear()
    {
        first = last = null;
    }

    public int size() 
    {
        return count;
    }

    public boolean isEmpty() 
    {
        return first == null && last == null;
    }

    public T[] toArray() 
    {
        Node<T> start = first;
        T[] temp = (T[]) new Object[count];
        for (int i = 0; i < count; i++) 
        {
            temp[i] = start.getData();
            start = start.getNext();
        }
        return temp;
    }

    public T get(int position) 
    {
        Node<T> n = first;
        for (int i = 1; i <= position; i++) 
        {
            n = n.getNext();
        }
        return n.getData();
    }

    private Node<T> getNodeAt(int position) 
    {
        Node<T> n = first;
        for (int i = 1; i <= position; i++) 
        {
            n = n.getNext();
        }
        return n;
    }

    public boolean contains(T data) 
    {
        Node<T> start = first;
        for (int i = 1; i < count; i++) 
        {
            if (start.getData().equals(data))
            {
                return true;
            }
            start = start.getNext();
        }
        return false;
    }
    
   

    @Override
    public T replace(int position, T item) 
    {
        // TODO Auto-generated method stub
        T toReplace = getNodeAt(position).getData();
        getNodeAt(position).setData(item);
        return toReplace;
    }
}// class