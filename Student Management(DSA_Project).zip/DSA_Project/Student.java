
public class Student 
{
	private int id;
	private String name;
	private String degree;
	private String course;
	private int semester;
	private double cgpa;
	
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Student(int id, String name, String degree, String course, int semester, double cgpa) {
		super();
		this.id = id;
		this.name = name;
		this.degree = degree;
		this.course = course;
		this.semester = semester;
		this.cgpa = cgpa;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getDegree() {
		return degree;
	}



	public void setDegree(String degree) {
		this.degree = degree;
	}



	public String getCourse() {
		return course;
	}



	public void setCourse(String course) {
		this.course = course;
	}



	public int getSemester() {
		return semester;
	}



	public void setSemester(int semester) {
		this.semester = semester;
	}



	public double getCgpa() {
		return cgpa;
	}



	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}



	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", degree=" + degree + ", course=" + course + ", semester="
				+ semester + ", cgpa=" + cgpa + "]";
	}
	
	
	
	
	
}
