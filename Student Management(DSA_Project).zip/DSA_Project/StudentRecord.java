import java.util.Scanner;
import java.util.Collections;
import java.util.Comparator;
public class StudentRecord 
{
	private List<Student> student;
	private Scanner in;
	private int id;
	
	public StudentRecord() 
	{
		student = new List<>();
		in = new Scanner(System.in);
		id=20198000;
	}
	
	public void addStudent()
	{
		System.out.println("\n");
		
		System.out.print("Enter student name :");
		String name =in.next();
		System.out.print("Enter student degree :");
		String degree =in.next();
		System.out.print("Enter degree Major :");
		String course =in.next();
		System.out.print("Enter student semester :");
		int semester =in.nextInt();
		System.out.print("Enter student cgpa :");
		double cgpa =in.nextDouble();
		
		student.add(new Student(id, name, degree, course, semester, cgpa));
		id++;
		System.out.println("\nStudent is added successfully!");
	}
	
	public void displayStudent()
	{
		System.out.println("\n\tDisplaying Student\n");
		if (student.size() != 0) 
        {
			for (int i = 0; i < student.size(); i++)
	            System.out.println(student.get(i));
        } else
            System.out.println("\nNo student is enrolled!");
	}
	
	public void updateStudent()
	{
		System.out.println("\n\tUpdating Student");
		if (student.size() != 0) 
        {
            System.out.print("\nEnter a student id to update: ");
            int index = search(in.nextInt());
        
            if (index == (-1))
            {
                System.out.println("\nStudent Not Found");
            }
            else
                update(student.get(index));
        } 
        else
            System.out.println("\nNo student is enrolled!");
	}
	
	public void delStudent()
	{
		System.out.println("\n\tDeleting Student\n");
		if (student.size() != 0) 
        {  
            System.out.print("\nEnter id of Student to delete: ");
            int index = search(in.nextInt());
        
            if (index != (-1)) 
            {
            	student.remove(index);
                System.out.println("\nStudent is deleted successfully!");
            } else
                System.out.println("\nStudent Not Found");
        } else
            System.out.println("\nNo student is available");
	}
	private int search(int id) 
    {
        for (int i = 0; i < student.size(); i++)
            if (student.get(i).getId() == id)
            {
                return i;
            }
        return -1;
    }
	
	private void update(Student student) 
    {
		
		System.out.println("Press 1 to update name");
		System.out.println("Press 2 to update degree");
		System.out.println("Press 3 to update Major");
		System.out.println("Press 4 to update semester");
		System.out.println("Press 5 to update cgpa");
		System.out.println("Press 0 to return home");
		
		System.out.print("Enter your choice :");
		int choice = in.nextInt();
		
		while(choice != 0)
		{
			switch (choice) 
			{
			case 1:
				System.out.print("Enter student name :");
				String name =in.next();
				student.setName(name);
				System.out.println("\nName updated successfully!");
				break;
			case 2:
				System.out.print("Enter student degree :");
				String degree =in.next();
				student.setDegree(degree);
				System.out.println("\nDegree updated successfully!");
				break;
			case 3:
				System.out.print("Enter degree Major :");
				String course =in.next();
				student.setCourse(course);
				System.out.println("\nMajor updated successfully!");
				break;
			case 4:
				System.out.print("Enter student semester :");
				int semester =in.nextInt();
				student.setSemester(semester);
				System.out.println("\nSemester updated successfully!");
				break;
			case 5:
				System.out.print("Enter student cgpa :");
				double cgpa =in.nextDouble();
				student.setCgpa(cgpa);
				System.out.println("\nCGPA updated successfully!");
				break;
			case 0:
				break;
			
			}
			
			System.out.println("\nPress 1 to update name");
			System.out.println("Press 2 to update degree");
			System.out.println("Press 3 to update Major");
			System.out.println("Press 4 to update semester");
			System.out.println("Press 5 to update cgpa");
			System.out.println("Press 0 to exit");
			
			System.out.print("Enter your choice :");
			choice = in.nextInt();
		}
		
    }
}
